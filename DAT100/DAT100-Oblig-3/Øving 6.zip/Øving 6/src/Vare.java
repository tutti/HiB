/**
 * Besvarelse p� oppgave 4
 * @author P�l V. Gjerde
 * @author Henriette Lie
 *
 */
public class Vare {
    // Objektvariabler
    private int varenr;
    private String navn;
    private double pris;
    
    // Konstanter for moms og utskrift av vare
    private static final double MOMS = 0.2;
    private static final String UTFORMAT = "#%d %s (kr %.2f)";
    
    /**
     * Konstrukt�r uten parametre
     * Oppretter en "navnl�s vare" med varenr og pris 0
     */
    public Vare() {
        this(0, "Navnl�s vare", 0.0);
    }

    /**
     * Konstrukt�r med parametre
     * @param varenr Varenummeret til varen
     * @param navn Navnet til varen
     * @param pris Hva varen koster
     */
    public Vare (int varenr, String navn, double pris) {
        this.varenr = varenr;
        this.navn = navn;
        this.pris = pris;
    }
    
    /*
     * Get/set-metoder
     */
    public int getVarenr() { return varenr; }
    public void setVarenr(int varenr) { this.varenr = varenr; }
    public String getNavn() { return navn; }
    public void setNavn(String navn) { this.navn = navn; }
    public double getPris() { return pris; }
    public void setPris(double pris) { this.pris = pris; }
    
    /**
     * Regner ut momsen (merverdiavgift) p� varen, rundet ned til to desimaler
     * @return Momsen p� varen
     */
    public double moms() {
        return (int)(pris*MOMS*100) / 100.0;
    }
    
    /**
     * Sjekker om denne varen er billigere enn en annen vare
     * @param v Den andre varen
     * @return true hvis denne varen er billigere, false hvis ikke
     */
    public boolean billigereEnn(Vare v) {
        return this.pris < v.pris;
    }
    
    /**
     * Skriver ut varens informasjon til skjermen
     */
    public void skriv() {
        System.out.println(toString());
    }
    
    /**
     * Returnerer varens informasjon i stringform
     */
    public String toString() {
        return String.format(UTFORMAT, varenr, navn, pris);
    }
    
    public static void main(String[] args) {
        Vare v1 = new Vare(1, "Testvare 1", 150);
        Vare v2 = new Vare(2, "Testvare 2", 220);
        System.out.print("Vare 1: ");
        v1.skriv();
        System.out.print("Vare 2: ");
        v2.skriv();
        System.out.println("Moms p� vare 1: "+v1.moms());
        System.out.println("Moms p� vare 2: "+v2.moms());
        System.out.println("Vare 1 billigere: "+v1.billigereEnn(v2));
    }
}