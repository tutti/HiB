/**
 * Besvarelse p� oppgave 1
 * @author P�l V. Gjerde
 * @author Henriette Lie
 *
 */
public class Oppgave1 {
    
    /**
     * Tar en streng og returnerer strengen baklengs
     * @param inn Strengen som skal vendes om
     * @return Den oppgitte strengen baklengs
     */
    public static String baklengs(String inn) {
        // Opprett en tom StringBuilder
        StringBuilder ut = new StringBuilder();
        
        // Les gjennom strengen i omvendt rekkef�lge (fra slutt til begynnelse)
        for (int i = inn.length()-1; i >= 0; --i) {
            // Legg til karakteren til StringBuilderen
            ut.append(inn.charAt(i));
        }
        
        // Returnerer strengen som ble bygget
        return ut.toString();
    }
    
    /**
     * Sjekker om en integerarray er sortert fra lavest til h�yest
     * @param inn En integerarray � sjekke
     * @return true hvis arrayen er sortert, false hvis ikke
     */
    public static boolean erSortert(int[] inn) {
        /* 
         * Kontroller at alle tallene i arrayen er st�rre eller likt tallet f�r.
         * Det f�rste tallet kontrolleres ikke siden det ikke har et tall f�r.
         * Hvis det finnes et tall som er mindre enn tallet f�r, returner false.
         */
        for (int i = 1; i < inn.length; ++i) {
            if (inn[i] < inn[i-1]) return false;
        }
        
        // Arrayen er sortert - returner true
        return true;
    }
    
    /**
     * Returnerer den strengen i en array som er f�rst i Unicode-rekkef�lge
     * @param inn En array av strenger
     * @return Strengen som er f�rst i Unicode-rekkef�lge
     */
    public static String forstIUnicode(String[] inn) {
        // Start med den f�rste strengen
        String ut = inn[0];
        
        // Sjekk alle strengene
        for (String enStreng : inn) {
            // Hvis en streng er f�r den vi har n�, bytt den vi har med den nye.
            if (enStreng.compareTo(ut) < 0) {
                ut = enStreng;
            }
        }
        
        // Returner den strengen vi fant
        return ut;
    }
    
    /**
     * Sammenligner to strenger for � se hvilken som kommer f�rst i
     * Unicode-rekkef�lge.
     * @param en Den f�rste strengen
     * @param to Den andre strengen
     * @return Et negativt tall hvis den f�rste strengen kommer f�r den andre;
     *      et positivt tall hvis den andre kommer f�r den f�rste; 0 hvis
     *      strengene er like
     */
    public static int sammenlignStrenger(String en, String to) {
        /*
         * Sammenlign hvert tegn i strengene (stopp hvis en streng g�r tom for
         * tegn).
         */
        for (int i = 0; i < Math.min(en.length(), to.length()); ++i) {
            /*
             * Hvis strengene har forskjellige tegn p� denne plassen, er de
             * forskjellige, og forskjellen mellom tegnene kan returneres som
             * forskjellen mellom strengene (siden det n�yaktige tallet ikke
             * har noe � si, kun positivt/negativt/0).
             */
            if (en.charAt(i) != to.charAt(i)) {
                return en.charAt(i) - to.charAt(i);
            }
        }
        
        /*
         *  Hvis ingen ulike tegn fantes, returner forskjellen mellom lengdene
         *  p� strengene. Hvis strengene er like vil dette v�re 0.
         */
        return en.length() - to.length();
    }
    
    public static void main(String[] args) {
        System.out.println("Teststreng baklengs: " + baklengs("Teststreng"));
        int[] t1 = {1, 2, 4, 6, 9};
        System.out.println("1, 2, 4, 6, 9 er sortert: " + erSortert(t1));
        int[] t2 = {1, 3, 2, 4, 7};
        System.out.println("1, 3, 2, 4, 7 er sortert: " + erSortert(t2));
        String[] t3 = {"En", "To", "Fire", "Seks", "Ni"};
        System.out.print("F�rst av En, To, Fire, Seks, Ni: ");
        System.out.println(forstIUnicode(t3));
        String[] t4 = {"Erlend", "Anne", "Nora", "Aila"};
        System.out.print("F�rst av Erlend, Anne, Nora, Aila: ");
        System.out.println(forstIUnicode(t4));
        System.out.print("Sammenlign 'Streng' og 'Streng2': ");
        System.out.println(sammenlignStrenger("Streng", "Streng2"));
        System.out.print("Sammenlign 'Streng2' og 'Streng': ");
        System.out.println(sammenlignStrenger("Streng2", "Streng"));
        System.out.print("Sammenlign 'Streng' og 'Streng': ");
        System.out.println(sammenlignStrenger("Streng", "Streng"));
    }
}