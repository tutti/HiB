import java.util.Arrays;
import java.util.Random;
import easyIO.Out;

/**
 * Besvarelse p� oppgave 3
 * Programmet kaster f�rst 100 terninger. Deretter teller det forekomsten av
 * hvert tall, og gjennomsnittet av alle tallene. S� skriver det ut antall kast
 * det tok for � f� en sekser, og hvilket tall som forekom oftest.
 * @author P�l V. Gjerde
 * @author Henriette Lie
 *
 */
public class Oppgave3 {
    private static Out out = new Out();
    private static Random rnd = new Random();
    
    // Antall kast
    public static final int ANTALL_KAST = 100;

    public static void main(String[] args) {
        // Arrays for alle kast og antall forekomster av hvert tall
        int[] kast = new int[ANTALL_KAST];
        int[] antall = new int[6];
        Arrays.fill(antall, 0);
        
        // Tellere for antall kast f�r en sekser kom, og summen av tallene
        int kastForSekser = 0;
        int sum = 0;
        
        // Overskrift for kastene
        out.outln("Kast:");
        
        for (int i=0; i < ANTALL_KAST; ++i) {
            // Kast en terning, lagre kastet i arrayet for kast, og legg til en
            // til antallet av det resultatet
            int detteKastet = rnd.nextInt(6)+1;
            kast[i] = detteKastet;
            ++antall[detteKastet-1];
            
            // Hvis dette er den f�rste sekseren, lagre antall kast det tok
            // � f� den
            if (kastForSekser == 0 && detteKastet == 6) {
                kastForSekser = i+1;
            }
            
            // �k summen og skriv ut kastet. Skriv ut ny linje hvis 25 kast
            // har blitt skrevet ut
            sum += detteKastet;
            out.out(detteKastet, 2, Out.LEFT);
            if ((i+1) % 25 == 0) out.outln();
        }
        
        // Skriv ut antall kast for hvert tall
        out.outln();
        out.outln("Antall kast per tall:");
        out.outln("---------------------");
        for (int i = 0; i < 6; ++i) {
            out.out(i+1, 5);
            out.outln(antall[i], 8);
        }
        out.outln();
        
        // Skriv ut gjennomsnittet (som et desimaltall med 3 desimaler)
        out.out("Gjennomsnitt av kastet: ");
        out.outln(sum / (float)ANTALL_KAST, 3);
        
        // Skriv ut antall kast f�r en sekser ble funnet
        out.out("Antall kast f�r f�rste sekser: ");
        out.outln(kastForSekser);
        
        // Finn ut hvilket tall forekom oftest
        int hoyesteAntall = 0;
        int oftesteKast = 0;
        for (int i = 0; i < 6; ++i) {
            if (antall[i] > hoyesteAntall) {
                hoyesteAntall = antall[i];
                oftesteKast = i+1;
            }
        }
        
        // Skriv ut tallet som forekom oftest
        out.out("Tallet som forekom oftest: ");
        out.outln(oftesteKast);
    }
}