import java.util.Arrays;
import java.util.Random;
import easyIO.Out;

/**
 * Besvarelse p� oppgave 2
 * @author P�l V. Gjerde
 * @author Henriette Lie
 *
 */
public class Oppgave2 {
    private static Out out = new Out();
    private static Random rnd = new Random();
    
    /**
     * M�ler tiden det tar � fylle en integerarray med tilfeldige tall (valgt
     * fra alle mulige integerverdier), og sortere den med Arrays.sort().
     * @param antallElementer Antall elementer arrayen skal inneholde
     * @return Tiden sorteringen tok, m�lt i millisekunder.
     */
    public static int malTid(int antallElementer) {
        // Opprett en array og fyll den med tilfeldige verdier
        int[] tilfeldig = new int[antallElementer];
        for (int i=0; i<tilfeldig.length; ++i) {
            tilfeldig[i] = rnd.nextInt();
        }
        
        // Les tid f�r sortering
        long tid1 = System.nanoTime();
        
        // Sorter array
        Arrays.sort(tilfeldig);
        
        // Les tid etter sortering, regn ut forskjell
        long tid2 = System.nanoTime();
        int forskjell = (int)((tid2 - tid1) / 1000000);
        
        // Returner forskjellen
        return forskjell;
    }
    
    /**
     * M�ler hvor lang tid det tar � sortere integerarray med forskjellige
     * st�rrelser som er fylt med tilfeldige tall. M�ler 20 ganger for hver
     * st�rrelse, skriver ut resultatet for hver m�ling samt gjennomsnittet
     * for alle 20 fors�kene med den st�rrelsen.
     * @param args Kreves for main-metoden, men brukes ikke.
     */
    public static void main(String[] args) {
        int[] antallElementer = {
            1000000,
            5000000,
            10000000,
            100000000
        };
        
        int antallForsok = 20;
        
        // For hvert antall som skal pr�ves:
        for (int antall : antallElementer) {
            int sum = 0;
            
            // Skriv ut overskriften
            out.outln(antall + " elementer:");
            out.out("Fors�k", 8, Out.LEFT);
            out.outln("Tid", 8, Out.LEFT);
            out.outln("----------------");
            
            // Pr�v 20 ganger
            for (int i=0; i < antallForsok; ++i) {
                // M�l tid, og skriv ut
                int tid = malTid(antall);
                sum += tid;
                out.out(i+1, 8);
                out.outln(tid + "ms", 8, Out.RIGHT);
            }
            
            // Regn ut og skriv ut gjennomsnittet av fors�kene
            out.outln("----------------");
            out.outln("Gjennomsnittlig tid: " + (sum/antallForsok) + "ms");
            out.outln();
        }
    }
}